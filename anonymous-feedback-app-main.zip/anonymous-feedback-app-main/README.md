## TruthWhisper
### An anonymous feedback platform

![CleanShot 2024-06-26 at 14 02 56](https://github.com/Megaminds-BD/anonymous-feedback-app/assets/831997/63e6a800-3a42-4528-b877-03d17c1d0e08)
